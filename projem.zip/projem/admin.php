<?php
session_start();
$page_title = 'Admin Girişi';

$error = '';

// KOŞUL YAPISI - Ödev gereksinimi: Form gönderildiyse giriş bilgilerini kontrol et
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    // KOŞUL YAPISI - Ödev gereksinimi: Kullanıcı adı ve şifre kontrolü
    if ($username === 'Salih1903' && $password === '1903') {
        $_SESSION['admin_logged_in'] = true;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Hatalı kullanıcı adı veya şifre girdiniz!';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav class="navbar container">
        <a href="index.php" class="logo">
            <span class="logo-icon">&lt;/&gt;</span> Salih Fırat
        </a>
        <div class="nav-links">
            <a href="index.php">Ana Sayfa</a>
        </div>
    </nav>

    <div class="login-wrapper container">
        <div class="login-card">
            <div class="login-icon"><i class="fas fa-lock"></i></div>
            <h2>Admin Paneli</h2>
            <p style="color: var(--text-muted); margin-bottom: 30px;">Bu alan site yöneticisi için ayrılmıştır.</p>

            <?php if (!empty($error)): ?>
                <div style="background-color: #f8d7da; color: #721c24; padding: 12px; border-radius: 6px; margin-bottom: 20px; text-align: center; font-size: 0.95rem; border: 1px solid #f5c6cb;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="admin.php" method="POST">
                <div class="form-group">
                    <label>Kullanıcı Adı</label>
                    <input type="text" name="username" class="form-input" placeholder="Kullanıcı adını yazın" required>
                </div>
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="password" class="form-input" placeholder="Şifrenizi yazın" required>
                </div>
                <button type="submit" class="btn-submit">Giriş Yap</button>
            </form>
        </div>
    </div>
</body>
</html>