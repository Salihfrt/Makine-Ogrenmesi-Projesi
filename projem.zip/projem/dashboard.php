<?php
session_start();

// GÜVENLİK KONTROLÜ - Giriş yetkisi yoksa admin girişine geri postala
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin.php');
    exit;
}

// Çıkış İşlemi
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['admin_logged_in']);
    session_destroy();
    header('Location: admin.php');
    exit;
}

$jsonFolder = __DIR__ . '/data';
$jsonFile = $jsonFolder . '/admin_blogs.json';

// Veri klasörü yoksa otomatik oluşturur
if (!file_exists($jsonFolder)) {
    mkdir($jsonFolder, 0777, true);
}

// JSON dosyasından mevcut verileri çeken fonksiyon
function loadAdminBlogs($file) {
    if (file_exists($file)) {
        $json = file_get_contents($file);
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }
    return [];
}

// JSON dosyasına verileri yazan fonksiyon
function saveAdminBlogs($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$adminBlogs = loadAdminBlogs($jsonFile);

// KOŞUL YAPISI - Panelden form ile yeni blog ekleme isteği geldiyse
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $tag = isset($_POST['tag']) ? trim($_POST['tag']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : date('Y-m-d');
    
    if (!empty($title) && !empty($tag)) {
        $newBlog = [
            'id' => time(), // Çakışmayı önlemek için zamana dayalı benzersiz ID
            'title' => $title,
            'tag' => $tag,
            'date' => $date,
            'from_admin' => true,
            'excerpt' => 'Bu yazı Admin panelinden yeni eklendi.',
            'content' => '<p>Bu içerik yönetim panelinden dinamik olarak JSON veritabanına yazdırılmıştır.</p>'
        ];
        
        array_unshift($adminBlogs, $newBlog); // Yeni yazıyı listenin en başına koy
        saveAdminBlogs($jsonFile, $adminBlogs);
        header('Location: dashboard.php?success=added');
        exit;
    }
}

// KOŞUL YAPISI - Silme isteği (çöp kutusu simgesine tıklandıysa) geldiyse
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $deleteId = (int)$_GET['id'];
    foreach ($adminBlogs as $index => $blog) {
        if ((int)$blog['id'] === $deleteId) {
            array_splice($adminBlogs, $index, 1); // Diziden çıkart
            saveAdminBlogs($jsonFile, $adminBlogs); // Güncel listeyi JSON'a kaydet
            header('Location: dashboard.php?success=deleted');
            exit;
        }
    }
}

// Toplam statik blog sayısı (9) + admin tarafından eklenen dinamik veri sayısı
$totalBlogsCount = 9 + count($adminBlogs);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); }
        .modal-content { background-color: var(--bg-card); margin: 10% auto; padding: 30px; border: 1px solid var(--border); border-radius: 12px; width: 90%; max-width: 500px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); position: relative; }
        .close-btn { position: absolute; right: 20px; top: 15px; font-size: 28px; cursor: pointer; color: var(--text-muted); }
        .close-btn:hover { color: var(--accent); }
        .admin-list-item { display: flex; justify-content: space-between; align-items: center; background: var(--bg-dark); padding: 15px; border-radius: 8px; margin-bottom: 10px; border: 1px solid var(--border); }
        .delete-icon { color: #ef4444; cursor: pointer; transition: 0.3s; }
        .delete-icon:hover { transform: scale(1.15); }
    </style>
</head>
<body>

    <nav class="navbar container">
        <div class="logo"><span class="logo-icon">&lt;/&gt;</span> Salih Fırat Panel</div>
        <div class="nav-links">
            <span style="color: white; margin-right: 15px;">Hoşgeldin, Salih1903</span>
            <a href="dashboard.php?action=logout" class="btn-admin" style="border-color: #ef4444; color: #ef4444;">Çıkış Yap</a>
        </div>
    </nav>

    <main class="container" style="padding-top: 40px;">
        <h1 style="margin-bottom: 30px;">Yönetim Paneli</h1>

        <?php if (isset($_GET['success'])): ?>
            <div style="background-color: #d4edda; color: #155724; padding: 12px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                <i class="fas fa-check-circle"></i> 
                <?php 
                    if ($_GET['success'] === 'added') echo 'Yeni yazı başarıyla eklendi ve admin_blogs.json dosyasına yazıldı!';
                    if ($_GET['success'] === 'deleted') echo 'Yazı veri dosyasından başarıyla silindi!';
                ?>
            </div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat-box">
                <div class="stat-number"><?php echo $totalBlogsCount; ?></div>
                <p>Toplam Blog Yazısı</p>
            </div>
            <div class="stat-box">
                <div class="stat-number">5</div>
                <p>Toplam Sayfa</p>
            </div>
            <div class="stat-box">
                <div class="stat-number">100%</div>
                <p>Site Durumu</p>
            </div>
        </div>

        <div class="form-box" style="max-width: 100%;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3>Yazı Listesi (Dinamik İçerikler)</h3>
                <button onclick="openModal()" class="btn-submit" style="width: auto; padding: 10px 20px;">+ Yeni Blog Ekle</button>
            </div>

            <div id="adminListArea">
                <?php if (empty($adminBlogs)): ?>
                    <p style="color: var(--text-muted); text-align: center; padding: 20px;">Henüz panelden eklenmiş dinamik yazı yok. Sağ üstten ilkini ekleyin!</p>
                <?php else: ?>
                    <?php 
                    // DÖNGÜ YAPISI - Ödev gereksinimi: JSON'dan gelen yazıları listeleme
                    foreach ($adminBlogs as $blog): 
                    ?>
                        <div class="admin-list-item">
                            <div>
                                <span class="tag"><?php echo htmlspecialchars($blog['tag']); ?></span>
                                <strong style="margin-left: 10px; color: var(--text-main);"><?php echo htmlspecialchars($blog['title']); ?></strong>
                                <br><small style="color: var(--text-muted);"><?php echo htmlspecialchars($blog['date']); ?></small>
                            </div>
                            <a href="dashboard.php?action=delete&id=<?php echo $blog['id']; ?>" onclick="return confirm('Bu yazıyı silmek istediğinize emin misiniz?')" class="delete-icon">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <div id="blogModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">Yeni Blog Ekle</h2>
            <form action="dashboard.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Blog Başlığı</label>
                    <input type="text" name="title" class="form-input" required placeholder="Örn: Yapay Zeka Gelişmeleri">
                </div>
                <div class="form-group">
                    <label>Kategori (Etiket)</label>
                    <input type="text" name="tag" class="form-input" required placeholder="Örn: Teknoloji">
                </div>
                <div class="form-group">
                    <label>Tarih</label>
                    <input type="date" name="date" class="form-input" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Listeye Ekle</button>
            </form>
        </div>
    </div>

    <footer>
        <div class="container copyright">
            &copy; 2026 Salih Fırat. Tüm hakları saklıdır.
        </div>
    </footer>

    <script>
        function openModal() { document.getElementById('blogModal').style.display = "block"; }
        function closeModal() { document.getElementById('blogModal').style.display = "none"; }
        window.onclick = function(event) {
            if (event.target == document.getElementById('blogModal')) { closeModal(); }
        }
    </script>
</body>
</html>