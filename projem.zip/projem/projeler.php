<?php
$page_title = 'Projelerim';
require_once 'includes/header.php';

// ÖDEV GEREKSİNİMİ: PHP Dizisi ve Döngü kullanımı için projeler verisi
$projeler = [
    [
        'isim' => 'Kişisel Blog Sitesi',
        'dil' => 'PHP, HTML, CSS',
        'aciklama' => 'Şu an incelemekte olduğunuz, dinamik veri yapısına sahip ve admin paneli bulunan web projesi.',
        'ikon' => 'fa-php'
    ],
    [
        'isim' => 'Öğrenci Yönetim Sistemi',
        'dil' => 'Java',
        'aciklama' => 'Nesne yönelimli programlama (OOP) prensipleri kullanılarak geliştirilmiş kapsamlı konsol uygulaması.',
        'ikon' => 'fa-java'
    ],
    [
        'isim' => 'Masaüstü Hesap Makinesi',
        'dil' => 'Python',
        'aciklama' => 'Tkinter kütüphanesi ile tasarlanmış, temel matematiksel işlemleri yapabilen masaüstü arayüzlü (GUI) uygulama.',
        'ikon' => 'fa-python'
    ]
];
?>

    <main class="container" style="padding-top: 40px; min-height: 60vh;">
        <div class="about-header" style="text-align: center; margin-bottom: 40px;">
            <h1>Projelerim</h1>
            <p style="color: var(--text-muted);">Eğitim hayatım boyunca geliştirdiğim yazılım projeleri ve çalışmalarım.</p>
        </div>

        <div class="features-grid">
            <?php 
            // ÖDEV GEREKSİNİMİ: Döngü yapısı (foreach) kullanımı
            foreach ($projeler as $proje): 
            ?>
                <div class="feature-card">
                    <div class="feature-icon" style="font-size: 2rem;"><i class="fab <?php echo htmlspecialchars($proje['ikon']); ?>"></i></div>
                    <h3><?php echo htmlspecialchars($proje['isim']); ?></h3>
                    <p style="color: var(--accent); font-size: 0.9rem; margin-bottom: 10px; font-weight: bold;">
                        <i class="fas fa-code"></i> <?php echo htmlspecialchars($proje['dil']); ?>
                    </p>
                    <p><?php echo htmlspecialchars($proje['aciklama']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

<?php require_once 'includes/footer.php'; ?>