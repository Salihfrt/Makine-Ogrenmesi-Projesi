<?php
$page_title = 'Ana Sayfa';
require_once 'includes/blog_data.php';
require_once 'includes/header.php';

// Son 3 blogu al (döngü kullanımı - ödev gereksinimi)
$allBlogs = getAllBlogs($blogData);
$sonYazilar = array_slice($allBlogs, 0, 3);
?>

    <header class="hero-modern container">
        <h1>Merhaba, Ben <span class="text-highlight">Salih Fırat</span></h1>
        <h3 class="hero-subtitle">Bilgisayar Programcılığı Öğrencisi</h3>
        <p class="hero-desc">
            İnönü Üniversitesi Malatya OSB Meslek Yüksekokulu'nda eğitim alıyorum.
            Akademik yazılım geliştirme sürecimi bu bloglarda paylaşıyorum.
        </p>
        <div class="hero-buttons">
            <a href="blog.php" class="btn-primary">
                Blog Yazılarını Oku <i class="fas fa-arrow-right" style="margin-left:8px;font-size:0.9em;"></i>
            </a>
            <a href="about.php" class="btn-outline">Hakkımda</a>
        </div>
    </header>

    <section class="features container">
        <div class="features-header">
            <h2>Blog Hakkında</h2>
            <p>Akademik yazılım geliştirme sürecimi ve öğrendiklerimi ve deneyimlerimi paylaşıyorum</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-code"></i></div>
                <h3>Yazılım Geliştirme</h3>
                <p>Web teknolojileri, programlama dilleri ve framework'ler üzerine yazılar</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-book-open"></i></div>
                <h3>Öğrenme Süreci</h3>
                <p>Eğitim sürecindeki deneyimlerim ve öğrenme yolculuğum</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="far fa-lightbulb"></i></div>
                <h3>Projeler & Fikirler</h3>
                <p>Geliştirdiğim projeler ve yazılım fikirleri</p>
            </div>
        </div>
    </section>

    <main class="container" style="margin-top: 80px;">
        <h2 class="section-title">Son Yazılar</h2>
        <div class="grid-layout">
            <?php
            // DÖNGÜ - Ödev gereksinimi: Son 3 yazıyı döngü ile listele
            foreach ($sonYazilar as $blog) :
                // KOŞUl - Admin'den mi yoksa normal blog mu?
                $isAdmin = isset($blog['from_admin']) && $blog['from_admin'] === true;
                $detailImg = $isAdmin
                    ? 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600&q=80'
                    : htmlspecialchars($blog['image']);
            ?>
            <article class="card">
                <img src="<?php echo $detailImg; ?>"
                     alt="<?php echo htmlspecialchars($blog['tag']); ?>" class="card-img">
                <div class="card-body">
                    <div class="meta">
                        <span class="tag"><?php echo htmlspecialchars($blog['tag']); ?></span>
                        <span><?php echo htmlspecialchars($blog['date']); ?></span>
                    </div>
                    <h3><?php echo htmlspecialchars($blog['title']); ?></h3>
                    <p><?php
                        // KOŞUL - Özet var mı kontrol et
                        if (!empty($blog['excerpt'])) {
                            echo htmlspecialchars($blog['excerpt']);
                        } else {
                            echo 'Bu yazı Admin panelinden eklendi. Detaylar için tıklayın.';
                        }
                    ?></p>
                    <a href="blog-detail.php?id=<?php echo (int)$blog['id']; ?>" class="read-more">Devamını Oku &rarr;</a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </main>

<?php require_once 'includes/footer.php'; ?>