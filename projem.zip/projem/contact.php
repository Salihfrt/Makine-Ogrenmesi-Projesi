<?php
$page_title = 'İletişim';
require_once 'includes/header.php';
?>

    <main class="container" style="padding-top: 40px; min-height: 60vh;">
        <div class="about-header">
            <h1>İletişim</h1>
            <p style="color: var(--text-muted);">Benimle iletişime geçmek için aşağıdaki formu kullanabilirsiniz.</p>
        </div>

        <div class="contact-cards">
            <div class="contact-item">
                <i class="fas fa-envelope"></i>
                <h3>E-posta</h3>
                <p><a href="mailto:slhfrt499@gmail.com" style="color: var(--text-main); text-decoration: none;">slhfrt499@gmail.com</a></p>
            </div>

            <div class="contact-item">
                <i class="fab fa-github"></i>
                <h3>GitHub</h3>
                <p><a href="https://github.com/Salihfrt" target="_blank" style="color: var(--text-main); text-decoration: none;">Profilimi Ziyaret Et</a></p>
            </div>

            <div class="contact-item">
                <i class="fab fa-linkedin"></i>
                <h3>LinkedIn</h3>
                <p><a href="https://www.linkedin.com/in/salih-fırat-a8807a402" target="_blank" style="color: var(--text-main); text-decoration: none;">Bağlantı Kur</a></p>
            </div>
        </div> <div class="form-box">
            <h3>Mesaj Gönder</h3>
            <form action="mailto:slhfrt499@gmail.com" method="post" enctype="text/plain">
                <div class="form-group">
                    <label>Adınız</label>
                    <input type="text" name="Ad_Soyad" class="form-input" placeholder="Adınızı girin" required>
                </div>
                <div class="form-group">
                    <label>Konu</label>
                    <input type="text" name="Konu" class="form-input" placeholder="Mesaj konusu" required>
                </div>
                <div class="form-group">
                    <label>Mesajınız</label>
                    <textarea name="Mesaj" class="form-input" rows="5" placeholder="Mesajınızı yazın" required></textarea>
                </div>
                
                <button type="submit" class="btn-submit"><i class="fas fa-paper-plane"></i> E-posta ile Gönder</button>
            </form>
            <p style="text-align: center; margin-top: 20px; font-size: 0.95rem; color: var(--accent);">
                <i class="fas fa-info-circle"></i> Not: Butona bastığınızda cihazınızdaki e-posta uygulaması açılacaktır.
            </p>
        </div>
    </main>

<?php require_once 'includes/footer.php'; ?>