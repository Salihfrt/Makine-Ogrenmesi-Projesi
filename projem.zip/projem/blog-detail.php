<?php
require_once 'includes/blog_data.php';

// URL'den id'yi al ve doğrula (koşul yapısı - ödev gereksinimi)
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// KOŞUL - id geçerli mi?
if ($id <= 0) {
    header('Location: blog.php');
    exit;
}

// Blog bul
$blog = findBlogById($blogData, $id);
$isAdmin = $blog && isset($blog['from_admin']) && $blog['from_admin'] === true;

// KOŞUL - Blog bulundu mu? Sayfa başlığını ayarla
$page_title = $blog ? $blog['title'] : 'Yazı Bulunamadı';
require_once 'includes/header.php';
?>

    <main class="container" style="padding-top: 40px;">
        <a href="blog.php" style="color: var(--accent); display: inline-block; margin-bottom: 20px;">&larr; Geri Dön</a>

        <?php if ($blog) : ?>
            <?php
            // KOŞUL - Admin blogunda resim var mı?
            $detailImg = $isAdmin
                ? 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80'
                : htmlspecialchars($blog['image_large'] ?? $blog['image']);
            ?>

            <article class="blog-detail">
                <img src="<?php echo $detailImg; ?>"
                     alt="<?php echo htmlspecialchars($blog['title']); ?>" class="blog-detail-img">

                <div class="meta" style="margin-bottom: 20px;">
                    <span class="tag"><?php echo htmlspecialchars($blog['tag']); ?></span>
                    <span><?php echo htmlspecialchars($blog['date']); ?></span>
                </div>

                <h1 style="font-size: 2.5rem; margin-bottom: 20px; line-height: 1.2;">
                    <?php echo htmlspecialchars($blog['title']); ?>
                </h1>

                <div class="blog-content">
                    <?php
                    // KOŞUL - Admin blogunda içerik var mı yoksa sadece başlık mı?
                    if (!empty($blog['content'])) {
                        // Normal blog: İçeriği göster (HTML izinli - veri PHP array'den geliyor)
                        echo $blog['content'];
                    } else {
                        echo '<p>Bu blog yazısının tam içeriği henüz eklenmemiş.</p>';
                    }
                    ?>
                </div>
            </article>

        <?php else : ?>
            <!-- KOŞUL - Blog bulunamadı mesajı -->
            <div style="text-align:center; padding: 80px 20px;">
                <i class="fas fa-search" style="font-size:3rem; color:var(--text-muted); margin-bottom:20px; display:block;"></i>
                <h2>Yazı Bulunamadı</h2>
                <p style="color:var(--text-muted); margin: 20px 0;">Aradığınız blog yazısı bulunamadı veya kaldırılmış olabilir.</p>
                <a href="blog.php" class="btn-primary" style="display:inline-block; margin-top:20px;">Tüm Yazılara Dön</a>
            </div>
        <?php endif; ?>

    </main>

<?php require_once 'includes/footer.php'; ?>
