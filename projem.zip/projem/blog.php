<?php
$page_title = 'Blog Yazıları';
require_once 'includes/blog_data.php';
require_once 'includes/header.php';

// Tüm blogları al (admin + normal)
$allBlogs = getAllBlogs($blogData);
?>

    <header class="hero container">
        <h1>Blog Yazılarım</h1>
        <p>Yazılım dünyasındaki öğrendiklerim ve notlarım.</p>
    </header>

    <main class="container">
        <div class="grid-layout">
            <?php
            // DÖNGÜ - Tüm blogları döngü ile listele (ödev gereksinimi)
            foreach ($allBlogs as $blog) :
                // KOŞUL - Admin'den mi yoksa normal blog mu?
                $isAdmin = isset($blog['from_admin']) && $blog['from_admin'] === true;
                $cardImg  = $isAdmin
                    ? 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600&q=80'
                    : htmlspecialchars($blog['image']);
            ?>
            <article class="card">
                <img src="<?php echo $cardImg; ?>"
                     alt="<?php echo htmlspecialchars($blog['tag']); ?>" class="card-img">
                <div class="card-body">
                    <div class="meta">
                        <span class="tag"><?php echo htmlspecialchars($blog['tag']); ?></span>
                        <span><?php echo htmlspecialchars($blog['date']); ?></span>
                    </div>
                    <h3><?php echo htmlspecialchars($blog['title']); ?></h3>
                    <p><?php
                        if (!empty($blog['excerpt'])) {
                            echo htmlspecialchars($blog['excerpt']);
                        } else {
                            echo 'Bu yazı Admin panelinden eklendi.';
                        }
                    ?></p>
                    <a href="blog-detail.php?id=<?php echo (int)$blog['id']; ?>" class="read-more">Devamını Oku &rarr;</a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </main>

<?php require_once 'includes/footer.php'; ?>
