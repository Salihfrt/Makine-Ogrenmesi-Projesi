<?php
// =====================================================
// BLOG VERİLERİ - PHP DİZİSİ (Veritabanı yerine)
// =====================================================
$blogData = [
    [
        'id'      => 1,
        'title'   => 'İngilizce Öğrenmenin Yazılımcıya Faydaları',
        'tag'     => 'Kişisel',
        'date'    => '2026-03-27',
        'image'   => 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Dokümantasyonları okumak ve global topluluklarla iletişim kurmak için İngilizce öğrenme sürecim.',
        'content' => '
            <p>Yazılım dünyasında İngilizce bilmenin önemi tartışılamaz bir gerçektir. Dokümantasyonları orijinal dilinden okumak, Stack Overflow gibi platformlarda sorunlara çözüm aramak ve global topluluklarla iletişim kurmak için İngilizce şart.</p>
            <h3>Neden İngilizce?</h3>
            <p>Çünkü programlama dillerinin ana dili İngilizcedir. "if", "else", "for", "while" gibi terimler zaten İngilizce kökenlidir. Hata mesajlarını (Error logs) anlamak için bile temel düzeyde İngilizce gerekir.</p>
            <h3>Benim Yöntemim</h3>
            <p>Ben, teknik makaleler okuyarak ve yabancı YouTube kanallarını takip ederek İngilizcemi geliştiriyorum. İnönü Üniversitesi eğitimim sırasında da terimlere aşina olmaya özen gösteriyorum.</p>
        '
    ],
    [
        'id'      => 2,
        'title'   => 'HTML ve CSS ile Modern Web Tasarımı',
        'tag'     => 'Web',
        'date'    => '2026-03-31',
        'image'   => 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Modern web tasarımı için Flexbox, Grid ve responsive tasarım prensipleri üzerine notlarım.',
        'content' => '
            <p>Web geliştirmenin temeli HTML ve CSS\'tir. Ancak günümüzde sadece div\'leri alt alta dizmek yetmiyor. Modern tasarım prensiplerini öğrenmek gerekiyor.</p>
            <h3>Flexbox ve Grid</h3>
            <p>Eskiden "float" ile yapılan hizalamalar artık yerini Flexbox ve CSS Grid sistemlerine bıraktı. Bu teknolojiler sayesinde responsive (mobil uyumlu) tasarımlar yapmak çok daha kolaylaştı.</p>
            <h3>Öğrenme Sürecim</h3>
            <p>Kendi kişisel blog sitemi (şu an gezdiğiniz site) yaparken CSS Grid yapısını kullandım. Renk paletlerini seçerken koyu tema (dark mode) prensiplerine dikkat ettim.</p>
        '
    ],
    [
        'id'      => 3,
        'title'   => 'Yazılımcı Olarak Kendimi Nasıl Geliştiriyorum',
        'tag'     => 'Gelişim',
        'date'    => '2026-04-02',
        'image'   => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Sürekli öğrenme ve gelişim, yazılım dünyasında başarılı olmak için şart.',
        'content' => '
            <p>Sürekli öğrenme, yazılım dünyasında hayatta kalmanın tek yoludur. Teknolojiler o kadar hızlı değişiyor ki, dün öğrendiğiniz bugün eskiyor olabilir.</p>
            <h3>Kaynaklarım</h3>
            <p>Udemy, YouTube (Özellikle freeCodeCamp), Medium makaleleri ve resmi dokümantasyonlar benim en büyük dostlarım. Ayrıca GitHub\'da başkalarının kodlarını incelemek de bana çok şey katıyor.</p>
            <h3>Pratik Yapmak</h3>
            <p>Sadece izleyerek öğrenilmez. "Tutorial Hell" denilen döngüye girmemek için öğrendiğim her şeyi küçük projelerle pekiştiriyorum.</p>
        '
    ],
    [
        'id'      => 4,
        'title'   => 'Cursor ile AI Destekli Kodlama',
        'tag'     => 'Araçlar',
        'date'    => '2026-04-05',
        'image'   => 'https://images.unsplash.com/photo-1605379399642-870262d3d051?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1605379399642-870262d3d051?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Yapay zeka destekli kod editörü Cursor, geliştirme sürecimi nasıl değiştirdi.',
        'content' => '
            <p>Son zamanlarda kullanmaya başladığım Cursor editörü, VS Code tabanlı ama içinde yapay zeka gömülü harika bir araç.</p>
            <h3>Neler Yapabiliyor?</h3>
            <p>Kod yazarken bir sonraki satırı tahmin ediyor, hataları ben sormadan analiz ediyor ve hatta "Bana bir iletişim formu yap" dediğimde taslağı oluşturuyor.</p>
            <h3>Yazılımcıyı Tembelleştirir mi?</h3>
            <p>Bence hayır. Aksine, hamallık dediğimiz tekrar eden işleri AI\'a yaptırıp, biz daha karmaşık mantıksal sorunlara odaklanabiliyoruz.</p>
        '
    ],
    [
        'id'      => 5,
        'title'   => 'C++ ile Veri Yapıları ve Algoritmalar',
        'tag'     => 'C++',
        'date'    => '2026-04-08',
        'image'   => 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'C++ kullanarak Linked List, Stack ve Queue gibi temel veri yapılarını uyguladım.',
        'content' => '
            <p>C++, bilgisayarın çalışma mantığını anlamak için harika bir dil. Özellikle bellek yönetimi (pointerlar) ve veri yapıları konusunda çok öğretici.</p>
            <h3>Linked List ve Stack</h3>
            <p>Okulda veri yapıları dersinde Linked List (Bağlı Liste) ve Stack (Yığın) yapılarını C++ ile implemente ettik. Bu yapılar, verilerin bellekte nasıl tutulduğunu anlamamı sağladı.</p>
        '
    ],
    [
        'id'      => 6,
        'title'   => 'Java ile Nesne Yönelimli Programlama',
        'tag'     => 'Java',
        'date'    => '2026-04-08',
        'image'   => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Sınıflar, nesneler, kalıtım ve polimorfizm. Java ile OOP öğrenme sürecim.',
        'content' => '
            <p>OOP (Nesne Yönelimli Programlama) modern yazılımın temel taşıdır. Java ise bu mantığı en iyi oturtmuş dillerden biri.</p>
            <h3>Temel Kavramlar</h3>
            <p>Sınıf (Class), Nesne (Object), Kalıtım (Inheritance) ve Polimorfizm kavramlarını Java üzerinde projeler geliştirerek öğreniyorum. Öğrenci yönetim sistemi projemde bu yapıları aktif olarak kullandım.</p>
        '
    ],
    [
        'id'      => 7,
        'title'   => 'Visual Studio Code ile Verimli Çalışma',
        'tag'     => 'Araçlar',
        'date'    => '2026-04-08',
        'image'   => 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Kod yazma hızımı artıran VS Code eklentileri ve kısayolları.',
        'content' => '
            <p>İyi bir yazılımcı, editörüne hakim olandır. VS Code, eklenti desteğiyle şu an dünyanın en popüler editörü.</p>
            <h3>Favori Eklentilerim</h3>
            <p>Prettier (Kod düzenleyici), Live Server (Anlık önizleme) ve GitLens (Versiyon kontrolü) olmazsa olmazlarım arasında.</p>
        '
    ],
    [
        'id'      => 8,
        'title'   => 'Python ile Programlamaya Giriş',
        'tag'     => 'Python',
        'date'    => '2026-04-09',
        'image'   => 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'Basit sözdizimi ve geniş kütüphane desteği ile Python öğrenme deneyimim.',
        'content' => '
            <p>Python, sözdizimi (syntax) İngilizceye çok yakın olduğu için öğrenmesi en keyifli dillerden biri.</p>
            <h3>Neler Yaptım?</h3>
            <p>Tkinter kütüphanesi ile masaüstü hesap makinesi uygulaması geliştirdim. Ayrıca veri analizi kütüphanelerine (Pandas, NumPy) giriş yaptım.</p>
        '
    ],
    [
        'id'      => 9,
        'title'   => 'Web Geliştirme Yolculuğuma Başlarken',
        'tag'     => 'Kişisel',
        'date'    => '2026-04-09',
        'image'   => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80',
        'image_large' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
        'excerpt' => 'İnönü Üniversitesi\'nde başladığım eğitim hayatım ve hedeflerim.',
        'content' => '
            <p>Merhaba, ben Salih Fırat. İnönü Üniversitesi Malatya OSB Meslek Yüksekokulu\'nda Bilgisayar Programcılığı bölümüne başladığımda hedeflerim büyüktü.</p>
            <p>Bu blog, benim öğrenme serüvenimin bir günlüğü olacak. Karşılaştığım hataları, öğrendiğim yeni teknolojileri ve projelerimi burada paylaşacağım.</p>
        '
    ],
];

// =====================================================
// ADMIN BLOG VERİLERİNİ JSON DOSYASINDAN OKU
// =====================================================
function getAdminBlogs() {
    $file = __DIR__ . '/data/admin_blogs.json';
    if (file_exists($file)) {
        $json = file_get_contents($file);
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }
    return [];
}

// Admin bloglarını varsayılan bloglarla birleştir
function getAllBlogs($blogData) {
    $adminBlogs = getAdminBlogs();
    // Admin bloglarını başa ekle
    return array_merge($adminBlogs, $blogData);
}

// ID'ye göre blog bul
function findBlogById($blogData, $id) {
    // Önce admin bloglarında ara
    $adminBlogs = getAdminBlogs();
    $allBlogs = array_merge($adminBlogs, $blogData);
    foreach ($allBlogs as $blog) {
        if (isset($blog['id']) && (int)$blog['id'] === (int)$id) {
            return $blog;
        }
    }
    return null;
}
