
<footer>
    <div class="container copyright">
        &copy; <?php echo date('Y'); ?> Salih Fırat. Tüm hakları saklıdır.
    </div>
</footer>

</body>
</html>
