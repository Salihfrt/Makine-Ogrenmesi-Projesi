<?php
// Aktif sayfayı belirle
$current_page = basename($_SERVER['PHP_SELF']);

function nav_class($page, $current) {
    return $page === $current ? 'class="active"' : '';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - Salih Fırat' : 'Salih Fırat'; ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<nav class="navbar container">
    <a href="index.php" class="logo">
        <span class="logo-icon">&lt;/&gt;</span> Salih Fırat
    </a>
    <div class="nav-links">
        <a href="index.php" <?php echo nav_class('index.php', $current_page); ?>>Ana Menü</a>
        <a href="blog.php" <?php echo nav_class('blog.php', $current_page); ?>>Blog</a>
        <a href="projeler.php" <?php echo nav_class('projeler.php', $current_page); ?>>Projeler</a>
        <a href="about.php" <?php echo nav_class('about.php', $current_page); ?>>Hakkımda</a>
        <a href="contact.php" <?php echo nav_class('contact.php', $current_page); ?>>İletişim</a>
        <a href="admin.php" class="btn-admin">Admin</a>
    </div>
</nav>