<?php
$page_title = 'Hakkımda';
require_once 'includes/blog_data.php';
require_once 'includes/header.php';

// Yetenekler dizisi - döngü için (ödev gereksinimi)
$yetenekler = ['Google Colab', 'Kaggle', 'Python', 'HTML / CSS', 'Visual Studio Code', 'PHP'];

// Projeler dizisi - döngü için
$projeler = [
    [
        'title' => 'Kişisel Blog Sitesi',
        'desc'  => 'HTML, CSS ve PHP kullanılarak geliştirilmiş modern blog sitesi.'
    ],
    [
        'title' => 'Öğrenci Yönetim Sistemi',
        'desc'  => 'Java OOP prensipleri kullanılarak geliştirilmiş konsol uygulaması.'
    ],
    [
        'title' => 'Python Hesap Makinesi',
        'desc'  => 'Tkinter ile geliştirilen masaüstü hesap makinesi uygulaması.'
    ],
];
?>

    <main class="container">
        <div class="about-header">
            <h1>Hakkımda</h1>
            <p style="color: var(--text-muted);">Bilgisayar programcılığı öğrencisi ve yazılım tutkunu</p>
        </div>

        <div class="about-hero">
            <img src="ahmet.png" alt="Salih Fırat" class="profile-pic">

            <div class="about-text">
                <h2>Merhaba!</h2>
                <p>Benim Adım Salih Fırat, 20 Yaşındayım. İnönü Üniversitesi Malatya OSB Meslek Yüksekokulu'nda
                Bilgisayar Programcılığı bölümünde öğrenciyim. Yazılım geliştirme alanında kendimi
                sürekli geliştirmek ve yeni teknolojiler öğrenmek için çalışıyorum.</p>

                <div class="skills-container">
                    <h3>Yetenekler & Araçlar</h3><br>
                    <?php
                    // DÖNGÜ - Yetenekleri listele (ödev gereksinimi)
                    foreach ($yetenekler as $yetenek) :
                    ?>
                        <span class="skill-badge"><?php echo htmlspecialchars($yetenek); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <h3 class="section-title">Projelerim</h3>
        <div class="grid-layout">
            <?php
            // DÖNGÜ - Projeleri listele
            foreach ($projeler as $proje) :
            ?>
            <div class="card">
                <div class="card-body">
                    <h3><?php echo htmlspecialchars($proje['title']); ?></h3>
                    <p><?php echo htmlspecialchars($proje['desc']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

<?php require_once 'includes/footer.php'; ?>
